<div id='legend' style="visibility: hidden">
    <h4>Points</h4>
    <i id="closeLegend" class="fa fa-window-minimize"></i>
    <div id="legendCircleBar"></div><div class="colorP">Bar</div>
    <div id="legendCircleRestaurant"></div><div class="colorP">Restaurant</div>
    <div id="legendCircleBarRestaurant"></div><div class="colorP">Bar-Restaurant</div>
</div>

<div id="smallLegend" style="visibility: hidden">Legend<i id="restore" class="fa fa-window-restore"></i></div>
